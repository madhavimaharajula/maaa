const express = require('express');
const fs = require('fs');
const path = require('path');
const { parsePhoneNumberFromString } = require('libphonenumber-js');

const app = express();
const PORT = process.env.PORT || 3000;

const DATA_DIR = path.join(__dirname, 'data');
const carriers = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'carriers_full.json'), 'utf8'));
const locations = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'locations_full.json'), 'utf8'));
const frauds = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'fraud_numbers.json'), 'utf8'));

app.use(express.static(path.join(__dirname, 'public')));

function longestMatch(mapObj, e164) {
  let best = null;
  for (const p of Object.keys(mapObj)) {
    if (e164.startsWith(p)) {
      if (!best || p.length > best.length) best = p;
    }
  }
  return best;
}

function computeRisk(e164, carrierPrefix) {
  if (frauds.includes(e164)) {
    return 85 + Math.floor(Math.random()*11);
  }
  if (carrierPrefix && carriers[carrierPrefix] && carriers[carrierPrefix].baseline) {
    let base = carriers[carrierPrefix].baseline;
    return Math.max(0, Math.min(100, base + (Math.floor(Math.random()*11)-5)));
  }
  return 15 + Math.floor(Math.random()*21);
}

app.get('/api/check', (req, res) => {
  const number = req.query.number;
  if (!number) return res.status(400).json({ error: 'number required' });

  let phone = parsePhoneNumberFromString(number);
  if (!phone) {
    phone = parsePhoneNumberFromString('+' + number.replace(/\D/g,''));
  }
  if (!phone || !phone.isValid()) {
    return res.json({ valid:false, explanation:'Invalid or unparseable number' });
  }
  const e164 = phone.number;

  const carrierPrefix = longestMatch(carriers, e164);
  const locationPrefix = longestMatch(locations, e164);

  const carrier = carrierPrefix ? carriers[carrierPrefix].carrier : 'Unknown';
  const location = locationPrefix ? locations[locationPrefix] : (phone.country || 'Unknown');
  const risk = computeRisk(e164, carrierPrefix);

  res.json({
    valid: true,
    number: e164,
    country: phone.country || null,
    carrier,
    location,
    risk,
    is_fraud_likely: risk >= 60,
    matched_carrier_prefix: carrierPrefix || null,
    matched_location_prefix: locationPrefix || null
  });
});

app.listen(PORT, () => console.log(`Number Sentinel (attempt4) running on http://localhost:${PORT}`));